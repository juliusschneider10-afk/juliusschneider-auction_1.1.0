package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.JuliusschneiderAuctionConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

public class JuliusschneiderSettingsScreen extends JuliusschneiderBaseScreen {
    private final Screen parent;
    private final JuliusschneiderAuctionConfig cfg = JuliusschneiderAuctionConfig.get();

    public JuliusschneiderSettingsScreen(Screen parent) {
        super("JuliusSchneider Auction - Einstellungen");
        this.parent = parent;
    }

    @Override
    protected void build() {
        int x = px + 14, w = pw - 28;
        EditBox idle = new EditBox(font, x, py + 62, w, 18, Component.literal("Werbetext"));
        idle.setMaxLength(256);
        idle.setValue(cfg.adTextIdle);
        idle.setResponder(s -> cfg.adTextIdle = s);
        addRenderableWidget(idle);
        EditBox live = new EditBox(font, x, py + 104, w, 18, Component.literal("Werbetext Auktion"));
        live.setMaxLength(256);
        live.setValue(cfg.adTextAuction);
        live.setResponder(s -> cfg.adTextAuction = s);
        addRenderableWidget(live);

        int bw = (w - 6) / 2;
        btn(x, py + 150, 24, 20, "-", MUTED, () -> { cfg.adCooldownSeconds = Math.max(0, cfg.adCooldownSeconds - 5); rebuildWidgets(); });
        btn(x + 28, py + 150, 24, 20, "+", MUTED, () -> { cfg.adCooldownSeconds = Math.min(600, cfg.adCooldownSeconds + 5); rebuildWidgets(); });
        btn(x, py + 178, bw, 22, "MINI-HUD: " + (cfg.hudEnabled ? "AN" : "AUS"), cfg.hudEnabled ? GREEN : MUTED,
                () -> { cfg.hudEnabled = !cfg.hudEnabled; rebuildWidgets(); });
        btn(x + bw + 6, py + 178, bw, 22, "10-SEK-SOUND: " + (cfg.warningSound ? "AN" : "AUS"), cfg.warningSound ? GREEN : MUTED,
                () -> { cfg.warningSound = !cfg.warningSound; rebuildWidgets(); });
        btn(x, py + 206, bw, 22, "HUD-POSITION: " + cfg.hudPosition.replace('_', ' '), BLUE,
                () -> { cfg.cyclePosition(); rebuildWidgets(); });
        btn(x + bw + 6, py + 206, bw, 22, "HUD-GROESSE: " + Math.round(cfg.hudScale * 100) + "%", BLUE,
                () -> { cfg.cycleScale(); rebuildWidgets(); });
        btn(x, py + 234, bw, 22, "DEBUG-LOG: " + (cfg.debugLogging ? "AN" : "AUS"), cfg.debugLogging ? GREEN : MUTED,
                () -> { cfg.debugLogging = !cfg.debugLogging; rebuildWidgets(); });
        btn(x, py + 262, w, 20, "ZAHLUNGSERKENNUNG: " + (cfg.paymentDetection ? "AN" : "AUS"), cfg.paymentDetection ? GREEN : MUTED,
                () -> { cfg.paymentDetection = !cfg.paymentDetection; rebuildWidgets(); });
        btn(x + bw + 6, py + 234, bw, 22, "FERTIG", GOLD, this::onClose);
    }

    @Override
    protected void draw(GuiGraphicsExtractor g, int mx, int my) {
        textScaled(g, "EINSTELLUNGEN", px + 14, py + 12, GOLD, 1.3f);
        text(g, "WERBETEXT OHNE AUKTION", px + 14, py + 50, MUTED);
        text(g, "WERBETEXT WAEHREND AUKTION  ([itemname] = Item)", px + 14, py + 92, MUTED);
        text(g, "WERBE-COOLDOWN: " + cfg.adCooldownSeconds + " s", px + 14 + 60, py + 156, TEXT);
    }

    @Override
    public void onClose() {
        JuliusschneiderAuctionConfig.save();
        Minecraft.getInstance().setScreen(parent);
    }
}
