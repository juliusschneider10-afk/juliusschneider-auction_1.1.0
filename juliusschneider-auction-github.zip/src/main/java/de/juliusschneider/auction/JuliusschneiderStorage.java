package de.juliusschneider.auction;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Kleine JSON-Listen-Persistenz im config-Ordner. */
public final class JuliusschneiderStorage {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private JuliusschneiderStorage() {}

    private static Path path(String file) { return FabricLoader.getInstance().getConfigDir().resolve(file); }

    public static <T> List<T> load(String file, Type listType) {
        try {
            Path p = path(file);
            if (Files.exists(p)) {
                List<T> l = GSON.fromJson(Files.readString(p), listType);
                if (l != null) return new ArrayList<>(l);
            }
        } catch (Exception e) {
            JuliusSchneiderAuction.LOGGER.error("Konnte {} nicht laden", file, e);
        }
        return new ArrayList<>();
    }

    public static void save(String file, Object list) {
        try {
            Files.writeString(path(file), GSON.toJson(list));
        } catch (Exception e) {
            JuliusSchneiderAuction.LOGGER.error("Konnte {} nicht speichern", file, e);
        }
    }
}
