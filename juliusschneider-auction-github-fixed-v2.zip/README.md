# JuliusSchneider Auction (Fabric, Minecraft 26.1.2)

Clientseitiges Auktionssystem: Setup-/Live-GUI, Mini-HUD, Werbung, Testsystem, vorbereitete Payment-Schnittstelle.

## Build
Java 25 + Gradle 9.4.1 noetig. Einmalig den Wrapper erzeugen: `gradle wrapper --gradle-version 9.4.1`
(oder gradlew/gradle-wrapper.jar aus der Fabric-Beispielmod kopieren). Dann `./gradlew build` -> `build/libs/`.
Versionen siehe gradle.properties (nach https://fabricmc.net/develop/ pruefen).

## Bedienung
- Taste **J** (aenderbar in Steuerung > JuliusSchneider Auction) oeffnet die GUI, ESC schliesst.
- Commands: `/juliusschneider auction open|start|end|reset|status|skip <sek>|testbid <spieler> <betrag>|testbids <anzahl>`
- Config: `config/juliusschneider_auction.json`
- Echte Payments: `JuliusschneiderBidProvider` implementieren, in `JuliusschneiderAuctionManager.registerProvider` anmelden und Gebote per `submitBid(...)` melden.

## Zahlungserkennung & Rueckzahlungen (ohne Vault, da fremder Server)
- Einstellungen > ZAHLUNGSERKENNUNG: AN. Die Mod wertet Server-Systemnachrichten per Regex aus
  (`paymentRegex` in der Config, Gruppen `player` und `amount`).
- Regex testen: `/juliusschneider auction paytest <Beispielzeile>`; setzen: `/juliusschneider auction payregex <regex>`.
- Nach Ende: Button RUECKZAHLUNGEN listet alle Zahlungen ausser dem Gewinnergebot; jeder Klick auf ZAHLEN sendet
  `refundCommand` (Standard `pay %player% %amount%`). Testgebote erzeugen keine Rueckzahlungen.
- Das Item musst du dem Gewinner selbst uebergeben (GUI/HUD zeigen Gewinner, Gebot und Item).
