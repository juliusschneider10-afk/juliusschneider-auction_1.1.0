package de.juliusschneider.auction;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.OptionalLong;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;

/**
 * Optionaler Provider: erkennt eingehende /pay-Zahlungen anhand zweier konfigurierbarer Regex
 * (paymentRegex und paymentRegexAlt, je mit den Gruppen "player" und "amount") in SERVER-Systemnachrichten
 * (nicht Spieler-Chat, damit niemand eine Zahlung per Chat vortaeuschen kann). Standardmaessig AUS.
 */
public final class JuliusschneiderChatPaymentProvider implements JuliusschneiderBidProvider {
    public static final JuliusschneiderChatPaymentProvider INSTANCE = new JuliusschneiderChatPaymentProvider();

    public record Parsed(String player, long amount) {}

    private final Map<String, Pattern> cache = new HashMap<>();

    @Override public String id() { return "chat-pay"; }

    public static void register() {
        JuliusschneiderAuctionManager.get().registerProvider(INSTANCE);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) INSTANCE.onMessage(message.getString());
        });
    }

    private Pattern pattern(String rx) {
        if (rx == null || rx.isBlank()) return null;
        try {
            return cache.computeIfAbsent(rx, Pattern::compile);
        } catch (PatternSyntaxException e) {
            return null;
        }
    }

    public Optional<Parsed> parse(String line) {
        var cfg = JuliusschneiderAuctionConfig.get();
        for (String rx : new String[]{cfg.paymentRegex, cfg.paymentRegexAlt}) {
            Pattern p = pattern(rx);
            if (p == null) continue;
            Matcher m = p.matcher(line);
            if (!m.find()) continue;
            try {
                String player = m.group("player");
                OptionalLong amount = JuliusschneiderAmountParser.parse(m.group("amount"));
                if (player != null && amount.isPresent() && amount.getAsLong() >= 1)
                    return Optional.of(new Parsed(player, amount.getAsLong()));
            } catch (IllegalArgumentException ignored) { // Gruppen fehlen in der Regex
            }
        }
        return Optional.empty();
    }

    public void onMessage(String line) {
        if (!JuliusschneiderAuctionConfig.get().paymentDetection) return;
        var mgr = JuliusschneiderAuctionManager.get();
        if (mgr.state() != JuliusschneiderAuctionState.RUNNING && mgr.state() != JuliusschneiderAuctionState.ENDED) return;
        var parsed = parse(line);
        if (parsed.isEmpty()) return;
        var mc = Minecraft.getInstance();
        if (mc.player != null && parsed.get().player().equalsIgnoreCase(mc.player.getName().getString())) return;
        var result = mgr.submitBid(parsed.get().player(), parsed.get().amount(), id());
        if (!result.ok()) {
            mgr.addUnmatchedPayment(parsed.get().player(), parsed.get().amount());
            JuliusschneiderAuctionManager.feedback("Zahlung von " + parsed.get().player() + " ("
                    + parsed.get().amount() + ") nicht als Gebot gewertet - Rueckzahlung vorgemerkt.");
        }
    }
}
