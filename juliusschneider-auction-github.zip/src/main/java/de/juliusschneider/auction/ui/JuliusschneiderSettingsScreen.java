package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.JuliusschneiderAuctionConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Einstellungen in drei Reitern: AUKTION, ANZEIGE, SOUND. */
public class JuliusschneiderSettingsScreen extends JuliusschneiderBaseScreen {
    private static final String[] TABS = {"AUKTION", "ANZEIGE", "SOUND"};
    private final Screen parent;
    private final JuliusschneiderAuctionConfig cfg = JuliusschneiderAuctionConfig.get();
    private int page;

    public JuliusschneiderSettingsScreen(Screen parent) {
        super("JuliusSchneider Auction - Einstellungen");
        this.parent = parent;
    }

    private static String onOff(boolean b) { return b ? "AN" : "AUS"; }

    private void toggle(int x, int y, int w, String label, boolean value, Runnable flip) {
        btn(x, y, w, 24, label + ": " + onOff(value), value ? GREEN : MUTED, () -> { flip.run(); rebuildWidgets(); });
    }

    @Override
    protected void build() {
        int x = px + 14, w = pw - 28, hw = (w - 6) / 2;
        int tw = (w - 12) / 3;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            btn(x + i * (tw + 6), py + 36, tw, 20, TABS[i], i == page ? GOLD : MUTED, () -> { page = idx; rebuildWidgets(); });
        }
        switch (page) {
            case 0 -> {
                EditBox idle = new EditBox(font, x, py + 82, w, 18, Component.literal("Werbetext"));
                idle.setMaxLength(256);
                idle.setValue(cfg.adTextIdle);
                idle.setResponder(s -> cfg.adTextIdle = s);
                addRenderableWidget(idle);
                EditBox live = new EditBox(font, x, py + 122, w, 18, Component.literal("Werbetext Auktion"));
                live.setMaxLength(256);
                live.setValue(cfg.adTextAuction);
                live.setResponder(s -> cfg.adTextAuction = s);
                addRenderableWidget(live);
                btn(x, py + 150, 24, 20, "-", MUTED, () -> { cfg.adCooldownSeconds = Math.max(0, cfg.adCooldownSeconds - 5); rebuildWidgets(); });
                btn(x + 28, py + 150, 24, 20, "+", MUTED, () -> { cfg.adCooldownSeconds = Math.min(600, cfg.adCooldownSeconds + 5); rebuildWidgets(); });
                toggle(x, py + 178, w, "ZAHLUNGSERKENNUNG", cfg.paymentDetection, () -> cfg.paymentDetection = !cfg.paymentDetection);
                btn(x, py + 208, hw, 24, "ANTI-SNIPING-FENSTER: " + cfg.antiSnipeWindowSeconds + " s", BLUE,
                        () -> { cfg.antiSnipeWindowSeconds = JuliusschneiderAuctionConfig.cycle(cfg.antiSnipeWindowSeconds, JuliusschneiderAuctionConfig.SNIPE_WINDOWS); rebuildWidgets(); });
                btn(x + hw + 6, py + 208, w - hw - 6, 24, "ZEIT SPRINGT AUF: " + cfg.antiSnipeExtendSeconds + " s", BLUE,
                        () -> { cfg.antiSnipeExtendSeconds = JuliusschneiderAuctionConfig.cycle(cfg.antiSnipeExtendSeconds, JuliusschneiderAuctionConfig.SNIPE_EXTENDS); rebuildWidgets(); });
            }
            case 1 -> {
                toggle(x, py + 70, hw, "MINI-HUD", cfg.hudEnabled, () -> cfg.hudEnabled = !cfg.hudEnabled);
                btn(x + hw + 6, py + 70, w - hw - 6, 24, "POSITION: " + cfg.hudPosition.replace('_', ' '), BLUE,
                        () -> { cfg.cyclePosition(); rebuildWidgets(); });
                btn(x, py + 100, hw, 24, "HUD-GRÖSSE: " + Math.round(cfg.hudScale * 100) + "%", BLUE,
                        () -> { cfg.cycleScale(); rebuildWidgets(); });
                int cw = (w - 4 * 4) / 5;
                for (int i = 0; i < THEMES.length; i++) {
                    final String name = THEMES[i];
                    boolean sel = name.equals(cfg.theme);
                    btn(x + i * (cw + 4), py + 168, cw, 24, name, themeAccent(name), true, () -> {
                        cfg.theme = name; applyTheme(name); rebuildWidgets(); });
                }
            }
            default -> {
                toggle(x, py + 70, hw, "10-SEK-SOUND", cfg.warningSound, () -> cfg.warningSound = !cfg.warningSound);
                toggle(x + hw + 6, py + 70, w - hw - 6, "GEWINNER-SOUND", cfg.winnerSound, () -> cfg.winnerSound = !cfg.winnerSound);
                toggle(x, py + 100, hw, "GEWINNER-ANIMATION", cfg.winnerAnimation, () -> cfg.winnerAnimation = !cfg.winnerAnimation);
                toggle(x + hw + 6, py + 100, w - hw - 6, "DEBUG-LOG", cfg.debugLogging, () -> cfg.debugLogging = !cfg.debugLogging);
            }
        }
        btn(x, py + ph - 46, w, 28, "FERTIG", GOLD, this::onClose);
    }

    @Override
    protected void draw(GuiGraphicsExtractor g, int mx, int my) {
        textScaled(g, "EINSTELLUNGEN", px + 14, py + 12, GOLD, 1.3f);
        int x = px + 14;
        if (page == 0) {
            text(g, "WERBETEXT OHNE AUKTION", x, py + 70, MUTED);
            text(g, "WERBETEXT WÄHREND AUKTION  ([itemname] = Item)", x, py + 110, MUTED);
            text(g, "WERBE-COOLDOWN: " + cfg.adCooldownSeconds + " s", x + 60, py + 156, TEXT);
        } else if (page == 1) {
            text(g, "FARBSCHEMA", x, py + 154, MUTED);
            text(g, "Wird sofort übernommen.", x, py + 200, MUTED);
        }
    }

    @Override
    public void onClose() {
        JuliusschneiderAuctionConfig.save();
        Minecraft.getInstance().setScreen(parent);
    }
}
