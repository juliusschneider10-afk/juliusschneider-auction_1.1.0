package de.juliusschneider.auction;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.CommandDispatcher;
import de.juliusschneider.auction.ui.JuliusschneiderAuctionScreen;
import net.fabricmc.fabric.api.client.command.v2.ClientCommands;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;

/** /juliusschneider auction <open|start|end|reset|skip|status|testbid|testbids> */
public final class JuliusschneiderAuctionCommands {
    private JuliusschneiderAuctionCommands() {}

    private static final JuliusschneiderAuctionManager M = JuliusschneiderAuctionManager.get();

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(ClientCommands.literal("juliusschneider")
            .then(ClientCommands.literal("auction")
                .then(ClientCommands.literal("open").executes(c -> {
                    Minecraft mc = Minecraft.getInstance();
                    mc.execute(() -> mc.setScreen(new JuliusschneiderAuctionScreen()));
                    return 1;
                }))
                .then(ClientCommands.literal("start").executes(c -> {
                    String err = null;
                    if (M.state() == JuliusschneiderAuctionState.IDLE) err = M.enterSetup();
                    if (err == null && !M.hasItem()) err = M.selectItemFromHand();
                    if (err == null) err = M.start();
                    return reply(c.getSource(), err, "Auktion gestartet: " + M.itemName());
                }))
                .then(ClientCommands.literal("end").executes(c -> reply(c.getSource(), M.end(), "Auktion beendet.")))
                .then(ClientCommands.literal("reset").executes(c -> reply(c.getSource(), M.reset(), "Auktion zurückgesetzt.")))
                .then(ClientCommands.literal("skip")
                    .then(ClientCommands.argument("sekunden", IntegerArgumentType.integer(1, 3600)).executes(c ->
                        reply(c.getSource(), M.skipSeconds(IntegerArgumentType.getInteger(c, "sekunden")), "Zeit vorgespult."))))
                .then(ClientCommands.literal("status").executes(c -> {
                    var l = M.leader();
                    c.getSource().sendFeedback(Component.literal("[JuliusSchneider Auction] " + M.state()
                        + " | Item: " + M.itemName() + " | Gebote: " + M.bidCount()
                        + " | Einnahmen: " + M.totalRevenue() + " | Leader: " + (l == null ? "-" : l.player() + " " + l.amount())));
                    return 1;
                }))
                .then(ClientCommands.literal("testbid")
                    .then(ClientCommands.argument("spieler", StringArgumentType.word())
                        .then(ClientCommands.argument("betrag", StringArgumentType.word()).executes(c -> {
                            var amount = JuliusschneiderAmountParser.parse(StringArgumentType.getString(c, "betrag"));
                            if (amount.isEmpty()) return reply(c.getSource(), "Ungültiger Betrag.", null);
                            var r = JuliusschneiderTestBidProvider.INSTANCE.bid(StringArgumentType.getString(c, "spieler"), amount.getAsLong());
                            return reply(c.getSource(), r.ok() ? null : r.message(), "Testgebot registriert.");
                        }))))
                .then(ClientCommands.literal("payregex")
                    .then(ClientCommands.argument("regex", StringArgumentType.greedyString()).executes(c -> {
                        String rx = StringArgumentType.getString(c, "regex");
                        try { java.util.regex.Pattern.compile(rx); }
                        catch (Exception e) { return reply(c.getSource(), "Ungültige Regex: " + e.getMessage(), null); }
                        JuliusschneiderAuctionConfig.get().paymentRegex = rx;
                        JuliusschneiderAuctionConfig.save();
                        return reply(c.getSource(), null, "Zahlungs-Regex gespeichert.");
                    })))
                .then(ClientCommands.literal("paytest")
                    .then(ClientCommands.argument("zeile", StringArgumentType.greedyString()).executes(c -> {
                        var p = JuliusschneiderChatPaymentProvider.INSTANCE.parse(StringArgumentType.getString(c, "zeile"));
                        return reply(c.getSource(), p.isEmpty() ? "Kein Treffer (Regex pruefen)." : null,
                                p.isEmpty() ? null : "Treffer: " + p.get().player() + " -> " + p.get().amount());
                    })))
                .then(ClientCommands.literal("testbids")
                    .then(ClientCommands.argument("anzahl", IntegerArgumentType.integer(1, 50)).executes(c -> {
                        int ok = JuliusschneiderTestBidProvider.INSTANCE.randomBids(IntegerArgumentType.getInteger(c, "anzahl"));
                        return reply(c.getSource(), null, ok + " Testgebote registriert.");
                    })))));
    }

    private static int reply(FabricClientCommandSource src, String err, String ok) {
        src.sendFeedback(Component.literal("[JuliusSchneider Auction] " + (err != null ? "Fehler: " + err : ok)));
        return err == null ? 1 : 0;
    }
}
