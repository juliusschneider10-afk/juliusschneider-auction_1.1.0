# Changelog

## 1.1.0
- Design: abgerundete Ecken bei Panels, Buttons und Balken
- HUD an/aus nur noch in den Einstellungen
- Zeitbalken ist jetzt ein durchgehender Balken (keine Unterteilung)
- Item aus der Hand wird im Setup automatisch uebernommen (Button und "Daten uebernommen"-Text entfernt)
- "-10 SEK" aus dem Hauptmenue entfernt
- Neues Test-Menue (Testgebot, 5 Testgebote, eigenes Testgebot); nicht mehr im Hauptmenue
- Zahlungserkennung: neue Standard-Regex fuer Meldungen wie "<Spieler> paid you $<Betrag>" (Hugo SMP, ungeprueft), zweite Regex fuer "received $X from <Spieler>"

## 1.0.0
- Erste Version
