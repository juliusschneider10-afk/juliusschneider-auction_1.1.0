# Changelog

## 1.2.0
- Hugo SMP (deutsch): Zahlungserkennung für "[Hugo SMP] Du hast $1 von Name erhalten" (am Zeilenanfang verankert)
- Zahlungslog (Button "LOG"): alle erkannten Zahlungen mit Ergebnis; zweite Ansicht mit den letzten Chat-Zeilen mit $ zur Fehlersuche
- Auktions-Verlauf (Button "VERLAUF"): alle beendeten Auktionen, dauerhaft gespeichert
- Anti-Sniping: im Setup schaltbar; Fenster und Zielzeit in den Einstellungen (Standard 10 s / 10 s)
- Farbschemata (GOLD, OZEAN, LILA, TÜRKIS, ROSA) in den Einstellungen
- Gewinner-Animation (Puls, Konfetti) und Gewinner-Sound (Vanilla "Herausforderung abgeschlossen"), einzeln abschaltbar
- Einstellungen in drei Reiter aufgeteilt (Auktion, Anzeige, Sound)
- Standard-Laufzeit im Setup: 45 Sekunden
- Richtige Umlaute (Ü, Ä, Ö) in der Oberfläche
- Rückzahlungen komplett entfernt

## 1.1.0
- Abgerundete Ecken, durchgehender Zeitbalken, automatische Item-Übernahme, Test-Menü, HUD-Schalter nur in den Einstellungen

## 1.0.0
- Erste Version
