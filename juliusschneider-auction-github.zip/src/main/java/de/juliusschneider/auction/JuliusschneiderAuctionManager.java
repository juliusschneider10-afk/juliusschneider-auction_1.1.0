package de.juliusschneider.auction;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.List;

/** Zentrale Auktionslogik (clientseitig, unabhaengig von jeder Server-Economy). */
public final class JuliusschneiderAuctionManager {
    private static final JuliusschneiderAuctionManager INSTANCE = new JuliusschneiderAuctionManager();
    public static JuliusschneiderAuctionManager get() { return INSTANCE; }

    public static final int[] DURATIONS = {10, 30, 45, 60, 120, 300, 600};
    public static final String[] DURATION_LABELS = {"10 SEK", "30 SEK", "45 SEK", "1 MIN", "2 MIN", "5 MIN", "10 MIN"};
    public static final long RESULT_HUD_MS = 45_000;
    public static final long WARNING_MS = 10_000;

    public record BidResult(boolean ok, String message) {}

    private JuliusschneiderAuctionState state = JuliusschneiderAuctionState.IDLE;
    private ItemStack item = ItemStack.EMPTY;
    private long minBid = 500_000;
    private int durationSeconds = 300;
    private long startMs, endMs, endedAtMs, leaderChangedAtMs;
    private long nextBidId = 1;
    private boolean warned;
    private final List<JuliusschneiderBid> bids = new ArrayList<>();
    private final List<JuliusschneiderBidProvider> providers = new ArrayList<>();
    private long lastAdMs;
    private boolean cancelled;
    private final Map<String, Long> unmatched = new LinkedHashMap<>();
    private final Map<String, Long> refunded = new LinkedHashMap<>();

    public record Refund(String player, long amount) {}
    public boolean cancelled() { return cancelled; }

    /** Gewinner nur nach regulaerem Ende (nicht bei Abbruch). */
    public JuliusschneiderBid winner() {
        return state == JuliusschneiderAuctionState.ENDED && !cancelled ? leader() : null;
    }

    /** Zahlung, die kein gueltiges Gebot wurde (zu niedrig / zu spaet): muss erstattet werden. */
    public void addUnmatchedPayment(String player, long amount) {
        if (state != JuliusschneiderAuctionState.RUNNING && state != JuliusschneiderAuctionState.ENDED) return;
        unmatched.merge(player, amount, Long::sum);
        JuliusSchneiderAuction.debug("Nicht zuordenbare Zahlung: " + player + " " + amount);
    }

    /** Offene Rueckzahlungen: alle echten (nicht-Test-)Zahlungen ausser dem Gewinnergebot. */
    public List<Refund> pendingRefunds() {
        if (state != JuliusschneiderAuctionState.ENDED) return List.of();
        var w = winner();
        Map<String, Long> t = new LinkedHashMap<>();
        for (var b : bids) {
            if ("test".equals(b.source())) continue;
            if (w != null && b.id() == w.id()) continue;
            t.merge(b.player(), b.amount(), Long::sum);
        }
        unmatched.forEach((p, a) -> t.merge(p, a, Long::sum));
        List<Refund> out = new ArrayList<>();
        t.forEach((p, a) -> {
            long left = a - refunded.getOrDefault(p, 0L);
            if (left > 0) out.add(new Refund(p, left));
        });
        out.sort(Comparator.comparingLong(Refund::amount).reversed());
        return out;
    }

    public void markRefunded(String player, long amount) { refunded.merge(player, amount, Long::sum); }

    private JuliusschneiderAuctionManager() {
        providers.add(JuliusschneiderTestBidProvider.INSTANCE);
    }

    // ---- Provider-Schnittstelle ----
    public void registerProvider(JuliusschneiderBidProvider p) { providers.add(p); }
    public void unregisterProvider(JuliusschneiderBidProvider p) { providers.remove(p); }

    // ---- Getter ----
    public JuliusschneiderAuctionState state() { return state; }
    public ItemStack item() { return item; }
    public boolean hasItem() { return !item.isEmpty(); }
    public String itemName() { return item.isEmpty() ? "-" : item.getHoverName().getString(); }
    public long minBid() { return minBid; }
    public int durationSeconds() { return durationSeconds; }
    public long leaderChangedAtMs() { return leaderChangedAtMs; }
    public long endedAtMs() { return endedAtMs; }

    public long remainingMs() {
        if (state == JuliusschneiderAuctionState.RUNNING) return Math.max(0, endMs - System.currentTimeMillis());
        return state == JuliusschneiderAuctionState.ENDED ? 0 : durationSeconds * 1000L;
    }

    public double progress() { // 1.0 = voll, 0.0 = vorbei
        if (state == JuliusschneiderAuctionState.ENDED) return 0;
        long total = Math.max(1, endMs - startMs);
        return state == JuliusschneiderAuctionState.RUNNING ? Math.min(1.0, remainingMs() / (double) total) : 1.0;
    }

    public boolean resultHudVisible() {
        return state == JuliusschneiderAuctionState.ENDED && System.currentTimeMillis() - endedAtMs < RESULT_HUD_MS;
    }

    /** Neueste zuerst. */
    public List<JuliusschneiderBid> recentBids() {
        List<JuliusschneiderBid> c = new ArrayList<>(bids);
        Collections.reverse(c);
        return c;
    }

    /** Alle Gebote nach Betrag absteigend, bei Gleichstand frueheres Gebot zuerst. */
    public List<JuliusschneiderBid> sortedBids() {
        List<JuliusschneiderBid> c = new ArrayList<>(bids);
        c.sort(Comparator.comparingLong(JuliusschneiderBid::amount).reversed().thenComparingLong(JuliusschneiderBid::id));
        return c;
    }

    public JuliusschneiderBid leader() {
        List<JuliusschneiderBid> s = sortedBids();
        return s.isEmpty() ? null : s.get(0);
    }

    public long totalRevenue() { return bids.stream().mapToLong(JuliusschneiderBid::amount).sum(); }
    public int bidCount() { return bids.size(); }

    // ---- Zustandswechsel ----
    public String enterSetup() {
        if (state != JuliusschneiderAuctionState.IDLE) return "Eine neue Auktion ist erst nach Zuruecksetzen moeglich.";
        var cfg = JuliusschneiderAuctionConfig.get();
        minBid = Math.max(1, cfg.lastMinBid);
        durationSeconds = cfg.lastDurationSeconds;
        item = ItemStack.EMPTY;
        state = JuliusschneiderAuctionState.SETUP;
        return null;
    }

    public String cancelSetup() {
        if (state != JuliusschneiderAuctionState.SETUP) return "Kein Setup aktiv.";
        item = ItemStack.EMPTY;
        state = JuliusschneiderAuctionState.IDLE;
        return null;
    }

    /** Uebernimmt das Item der Haupthand inkl. aller Komponenten (Name, Lore, Enchants, Attribute, Custom Data). */
    public String selectItemFromHand() {
        if (state != JuliusschneiderAuctionState.SETUP) return "Item kann nur im Setup gewaehlt werden.";
        var player = Minecraft.getInstance().player;
        if (player == null) return "Kein Spieler vorhanden.";
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) return "Du haeltst kein Item in der Hand.";
        item = held.copy();
        JuliusSchneiderAuction.debug("Item ausgewaehlt: " + item.getCount() + "x " + itemName());
        return null;
    }

    /** Uebernimmt automatisch das gehaltene Item (nur im Setup, still, ohne Fehlermeldung). */
    public void autoSelectFromHand() {
        if (state != JuliusschneiderAuctionState.SETUP) return;
        var player = Minecraft.getInstance().player;
        if (player == null) return;
        ItemStack held = player.getMainHandItem();
        if (held.isEmpty()) return;
        if (item.isEmpty() || !ItemStack.matches(item, held)) {
            item = held.copy();
            JuliusSchneiderAuction.debug("Item automatisch uebernommen: " + item.getCount() + "x " + itemName());
        }
    }

    public String setMinBid(long value) {
        if (state != JuliusschneiderAuctionState.SETUP) return "Mindestgebot ist waehrend der Auktion gesperrt.";
        if (value < 1) return "Mindestgebot muss mindestens 1 sein.";
        minBid = value;
        JuliusschneiderAuctionConfig.get().lastMinBid = value;
        return null;
    }

    public String setDuration(int seconds) {
        if (state != JuliusschneiderAuctionState.SETUP) return "Laufzeit ist waehrend der Auktion gesperrt.";
        for (int d : DURATIONS) if (d == seconds) {
            durationSeconds = seconds;
            JuliusschneiderAuctionConfig.get().lastDurationSeconds = seconds;
            return null;
        }
        return "Ungueltige Laufzeit.";
    }

    public String start() {
        if (state != JuliusschneiderAuctionState.SETUP) return "Auktion kann nur aus dem Setup gestartet werden.";
        if (item.isEmpty()) return "Bitte zuerst ein Item auswaehlen.";
        if (minBid < 1) return "Ungueltiges Mindestgebot.";
        bids.clear();
        nextBidId = 1;
        warned = false;
        startMs = System.currentTimeMillis();
        endMs = startMs + durationSeconds * 1000L;
        leaderChangedAtMs = 0;
        state = JuliusschneiderAuctionState.RUNNING;
        JuliusschneiderAuctionConfig.save();
        JuliusSchneiderAuction.debug("Auktion gestartet: " + itemName() + ", min=" + minBid + ", " + durationSeconds + "s");
        for (var p : providers) p.onAuctionStarted(this);
        return null;
    }

    /** Aufrufen jeden Client-Tick. */
    public void tick() {
        if (state != JuliusschneiderAuctionState.RUNNING) return;
        long rem = remainingMs();
        if (!warned && rem <= WARNING_MS) {
            warned = true;
            if (JuliusschneiderAuctionConfig.get().warningSound) playWarning();
        }
        if (rem <= 0) end();
    }

    private void playWarning() {
        var mc = Minecraft.getInstance();
        if (mc.getSoundManager() != null)
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_PLING, 1.0f));
    }

    /** Beendet die Auktion regulaer (Gewinner = Leader). */
    public String end() {
        if (state != JuliusschneiderAuctionState.RUNNING) return "Keine laufende Auktion.";
        state = JuliusschneiderAuctionState.ENDED;
        endedAtMs = System.currentTimeMillis();
        var l = leader();
        JuliusSchneiderAuction.debug(l == null ? "Auktion beendet: keine Gebote"
                : "Auktion beendet. Gewinner: " + l.player() + " mit " + l.amount());
        for (var p : providers) p.onAuctionEnded(this);
        return null;
    }

    /** Bricht eine laufende Auktion ab (ohne Gewinner) und kehrt zu IDLE zurueck. */
    public String abort() {
        if (state != JuliusschneiderAuctionState.RUNNING) return "Keine laufende Auktion.";
        JuliusSchneiderAuction.debug("Auktion abgebrochen");
        cancelled = true;
        state = JuliusschneiderAuctionState.ENDED;
        endedAtMs = System.currentTimeMillis();
        for (var p : providers) p.onAuctionEnded(this);
        return null;
    }

    public String reset() {
        if (state == JuliusschneiderAuctionState.IDLE) return "Bereits zurueckgesetzt.";
        JuliusSchneiderAuction.debug("Auktion zurueckgesetzt");
        clear();
        return null;
    }

    private void clear() {
        bids.clear();
        unmatched.clear();
        refunded.clear();
        cancelled = false;
        item = ItemStack.EMPTY;
        warned = false;
        state = JuliusschneiderAuctionState.IDLE;
    }

    /** Test: Zeit vorspulen. */
    public String skipSeconds(int seconds) {
        if (state != JuliusschneiderAuctionState.RUNNING) return "Keine laufende Auktion.";
        endMs -= seconds * 1000L;
        startMs -= 0;
        return null;
    }

    // ---- Gebote ----
    public BidResult submitBid(String player, long amount, String source) {
        if (state != JuliusschneiderAuctionState.RUNNING) return new BidResult(false, "Keine laufende Auktion.");
        if (player == null || player.isBlank()) return new BidResult(false, "Spielername fehlt.");
        if (amount < minBid) return new BidResult(false, "Gebot liegt unter dem Mindestgebot.");
        var before = leader();
        var bid = new JuliusschneiderBid(nextBidId++, player, amount, System.currentTimeMillis(), source);
        bids.add(bid);
        var after = leader();
        JuliusSchneiderAuction.debug("Gebot #" + bid.id() + ": " + player + " " + amount + " (" + source + ")");
        if (after != null && (before == null || after.id() != before.id())) {
            leaderChangedAtMs = System.currentTimeMillis();
            JuliusSchneiderAuction.debug("Neuer Leader: " + after.player() + " " + after.amount());
        }
        return new BidResult(true, "Gebot registriert.");
    }

    // ---- Werbung ----
    public long adCooldownRemainingMs() {
        long cd = JuliusschneiderAuctionConfig.get().adCooldownSeconds * 1000L;
        return Math.max(0, lastAdMs + cd - System.currentTimeMillis());
    }

    public String sendAdvert() {
        var mc = Minecraft.getInstance();
        if (mc.player == null) return "Nicht im Spiel.";
        long rem = adCooldownRemainingMs();
        if (rem > 0) return "Werbe-Cooldown: noch " + (rem / 1000 + 1) + "s";
        var cfg = JuliusschneiderAuctionConfig.get();
        boolean live = state == JuliusschneiderAuctionState.RUNNING;
        String text = live ? cfg.adTextAuction.replace("[itemname]", itemName()) : cfg.adTextIdle;
        if (text.isBlank()) return "Werbetext ist leer (Einstellungen).";
        lastAdMs = System.currentTimeMillis();
        if (text.startsWith("/")) mc.player.connection.sendCommand(text.substring(1));
        else mc.player.connection.sendChat(text);
        return null;
    }

    public static void feedback(String msg) {
        var p = Minecraft.getInstance().player;
        if (p != null) p.displayClientMessage(Component.literal("[JuliusSchneider Auction] " + msg), false);
    }
}
