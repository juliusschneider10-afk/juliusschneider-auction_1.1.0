package de.juliusschneider.auction;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Persistente Einstellungen: config/juliusschneider_auction.json */
public final class JuliusschneiderAuctionConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static JuliusschneiderAuctionConfig instance = new JuliusschneiderAuctionConfig();

    /** Hugo SMP (deutsch): "[Hugo SMP] Du hast $1 von Name erhalten" - am Zeilenanfang verankert (Schutz vor Chat-Fälschung). */
    public static final String DEFAULT_REGEX =
            "(?i)^\\s*\\[hugo ?smp\\]\\W*du hast \\$?\\s*(?<amount>[\\d.,]+\\s?[kmb]?)\\s+von\\s+(?<player>[\\w.]{3,16})\\s+erhalten";
    /** Vermutete englische Variante (ungeprüft). */
    public static final String DEFAULT_REGEX_ALT =
            "(?i)^\\s*\\[hugo ?smp\\]\\W*you (?:have )?received \\$?\\s*(?<amount>[\\d.,]+\\s?[kmb]?)\\s+from\\s+(?<player>[\\w.]{3,16})";

    public int configVersion = 0;
    public String adTextIdle = "Live auf Twitch: Auktionen, Giveaways und mehr!";
    public String adTextAuction = "[itemname] Auktion von juliusschneider ist jetzt live!";
    public int adCooldownSeconds = 30;
    public boolean hudEnabled = true;
    public boolean warningSound = true;
    public boolean winnerSound = true;
    public boolean winnerAnimation = true;
    public boolean debugLogging = false;
    public String hudPosition = "TOP_RIGHT"; // TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT
    public float hudScale = 1.0f;
    public String theme = "GOLD";
    public long lastMinBid = 500_000;
    public boolean lastAntiSniping = false;
    public int antiSnipeWindowSeconds = 10;
    public int antiSnipeExtendSeconds = 10;
    public boolean paymentDetection = false;
    public String paymentRegex = DEFAULT_REGEX;
    public String paymentRegexAlt = DEFAULT_REGEX_ALT;

    public static final String[] POSITIONS = {"TOP_LEFT", "TOP_RIGHT", "BOTTOM_RIGHT", "BOTTOM_LEFT"};
    public static final float[] SCALES = {0.75f, 1.0f, 1.25f, 1.5f};
    public static final int[] SNIPE_WINDOWS = {5, 10, 15, 20, 30};
    public static final int[] SNIPE_EXTENDS = {5, 10, 15, 30};

    public static JuliusschneiderAuctionConfig get() { return instance; }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("juliusschneider_auction.json");
    }

    public static void load() {
        try {
            if (Files.exists(path())) {
                var c = GSON.fromJson(Files.readString(path()), JuliusschneiderAuctionConfig.class);
                if (c != null) instance = c;
            }
        } catch (Exception e) {
            JuliusSchneiderAuction.LOGGER.error("Config konnte nicht geladen werden", e);
        }
        if (instance.configVersion < 2) { // Migration: neue Hugo-SMP-Erkennung übernehmen
            instance.paymentRegex = DEFAULT_REGEX;
            instance.paymentRegexAlt = DEFAULT_REGEX_ALT;
            instance.configVersion = 2;
        }
        if (instance.theme == null) instance.theme = "GOLD";
        if (instance.adCooldownSeconds < 0) instance.adCooldownSeconds = 0;
        save();
    }

    public static void save() {
        try {
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception e) {
            JuliusSchneiderAuction.LOGGER.error("Config konnte nicht gespeichert werden", e);
        }
    }

    public void cyclePosition() {
        for (int i = 0; i < POSITIONS.length; i++)
            if (POSITIONS[i].equals(hudPosition)) { hudPosition = POSITIONS[(i + 1) % POSITIONS.length]; return; }
        hudPosition = POSITIONS[0];
    }

    public void cycleScale() {
        for (int i = 0; i < SCALES.length; i++)
            if (Math.abs(SCALES[i] - hudScale) < 0.01f) { hudScale = SCALES[(i + 1) % SCALES.length]; return; }
        hudScale = 1.0f;
    }

    public static int cycle(int current, int[] values) {
        for (int i = 0; i < values.length; i++) if (values[i] == current) return values[(i + 1) % values.length];
        return values[0];
    }
}
