package de.juliusschneider.auction;

public enum JuliusschneiderAuctionState { IDLE, SETUP, RUNNING, ENDED }
