package de.juliusschneider.auction;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

import java.util.HashMap;
import java.util.Map;

/**
 * Cacht Spieler-Skins (nur Spieler, die der Client kennt, z.B. Tab-Liste).
 * Fuer unbekannte Spieler wird ein neutraler Fallback-Avatar gezeichnet.
 * ALLE skin-spezifischen Minecraft-APIs liegen in dieser einen Methode: lookup().
 */
public final class JuliusschneiderSkinManager {
    private static final JuliusschneiderSkinManager INSTANCE = new JuliusschneiderSkinManager();
    public static JuliusschneiderSkinManager get() { return INSTANCE; }

    private final Map<String, Identifier> cache = new HashMap<>();

    private Identifier lookup(String name) {
        Identifier cached = cache.get(name.toLowerCase());
        if (cached != null) return cached;
        var conn = Minecraft.getInstance().getConnection();
        if (conn == null) return null;
        var info = conn.getPlayerInfo(name);
        if (info == null) return null;
        Identifier tex = info.getSkin().body().texturePath();
        cache.put(name.toLowerCase(), tex);
        return tex;
    }

    public void clearCache() { cache.clear(); }

    public void drawHead(GuiGraphicsExtractor g, String name, int x, int y, int size) {
        Identifier tex = name == null ? null : lookup(name);
        if (tex != null) {
            g.blit(RenderPipelines.GUI_TEXTURED, tex, x, y, 8f, 8f, size, size, 8, 8, 64, 64);
            g.blit(RenderPipelines.GUI_TEXTURED, tex, x, y, 40f, 8f, size, size, 8, 8, 64, 64);
            return;
        }
        // neutraler Fallback: grauer Block mit Initial
        g.fill(x, y, x + size, y + size, 0xFF3A4150);
        g.fill(x + 1, y + 1, x + size - 1, y + size - 1, 0xFF2A303C);
        String s = (name == null || name.isEmpty()) ? "?" : name.substring(0, 1).toUpperCase();
        var font = Minecraft.getInstance().font;
        g.text(font, s, x + (size - font.width(s)) / 2, y + (size - 8) / 2, 0xFFAAB2C0, false);
    }
}
