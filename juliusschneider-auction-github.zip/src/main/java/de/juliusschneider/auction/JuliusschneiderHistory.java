package de.juliusschneider.auction;

import com.google.gson.reflect.TypeToken;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Speicher aller beendeten Auktionen (config/juliusschneider_auction_history.json). */
public final class JuliusschneiderHistory {
    public static class Entry {
        public long startedAt, endedAt;
        public String item = "";
        public int count = 1;
        public String winner; // null = keiner
        public long winningBid;
        public long revenue;
        public int bids;
        public boolean cancelled;
        public boolean test;
        public int durationSeconds;
    }

    private static final String FILE = "juliusschneider_auction_history.json";
    private static List<Entry> entries = new ArrayList<>();

    private JuliusschneiderHistory() {}

    public static void load() {
        entries = JuliusschneiderStorage.load(FILE, new TypeToken<List<Entry>>() {}.getType());
    }

    public static void add(Entry e) {
        entries.add(e);
        JuliusschneiderStorage.save(FILE, entries);
    }

    public static List<Entry> newestFirst() {
        List<Entry> c = new ArrayList<>(entries);
        Collections.reverse(c);
        return c;
    }

    public static long totalRevenue() {
        return entries.stream().filter(e -> !e.test && !e.cancelled).mapToLong(e -> e.revenue).sum();
    }

    public static int count() { return (int) entries.stream().filter(e -> !e.test).count(); }
}
