package de.juliusschneider.auction.ui;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.ItemStack;

import java.text.NumberFormat;
import java.util.Locale;

/** Gemeinsame Zeichenhelfer und Farbpalette des JuliusSchneider-Auction-Looks. */
public final class JuliusschneiderUi {
    public static final int BG = 0xF00D1117, PANEL = 0xD9161B22, PANEL_HI = 0xD9212A36, BORDER = 0xFF30363D;
    public static final int GOLD = 0xFFF5B83D, GREEN = 0xFF3FB950, RED = 0xFFF85149, BLUE = 0xFF58A6FF;
    public static final int TEXT = 0xFFE6EDF3, MUTED = 0xFF8B949E;

    private JuliusschneiderUi() {}

    public static Font font() { return Minecraft.getInstance().font; }
    public static int width(String s) { return font().width(s); }

    private static int inset(int row, int r) {
        double dy = r - row - 0.5;
        double dx = Math.sqrt(Math.max(0, r * (double) r - dy * dy));
        return (int) Math.round(r - dx);
    }

    /** Gefuelltes Rechteck mit abgerundeten Ecken (ohne ueberlappende Zeilen, daher alpha-sicher). */
    public static void rounded(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int color) {
        r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
        if (r == 0) { g.fill(x, y, x + w, y + h, color); return; }
        for (int i = 0; i < r; i++) {
            int in = inset(i, r);
            g.fill(x + in, y + i, x + w - in, y + i + 1, color);
            g.fill(x + in, y + h - 1 - i, x + w - in, y + h - i, color);
        }
        g.fill(x, y + r, x + w, y + h - r, color);
    }

    public static void panelR(GuiGraphicsExtractor g, int x, int y, int w, int h, int r, int fill, int border) {
        rounded(g, x, y, w, h, r, border);
        rounded(g, x + 1, y + 1, w - 2, h - 2, Math.max(1, r - 1), fill);
    }

    public static void panel(GuiGraphicsExtractor g, int x, int y, int w, int h, int fill, int border) {
        panelR(g, x, y, w, h, Math.min(w, h) < 16 ? 2 : 4, fill, border);
    }

    public static void text(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(font(), s, x, y, color, true);
    }

    public static void textRight(GuiGraphicsExtractor g, String s, int rightX, int y, int color) {
        text(g, s, rightX - width(s), y, color);
    }

    public static void centered(GuiGraphicsExtractor g, String s, int cx, int y, int color) {
        text(g, s, cx - width(s) / 2, y, color);
    }

    public static void textScaled(GuiGraphicsExtractor g, String s, int x, int y, int color, float scale) {
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.text(font(), s, 0, 0, color, true);
        g.pose().popMatrix();
    }

    public static void item(GuiGraphicsExtractor g, ItemStack stack, int x, int y, float scale) {
        if (stack.isEmpty()) return;
        g.pose().pushMatrix();
        g.pose().translate(x, y);
        g.pose().scale(scale, scale);
        g.item(stack, 0, 0);
        g.itemDecorations(font(), stack, 0, 0);
        g.pose().popMatrix();
    }

    /** Durchgehender, abgerundeter Balken (kein Segment-Look). */
    public static void bar(GuiGraphicsExtractor g, int x, int y, int w, int h, double frac, int color) {
        int r = Math.min(4, h / 2);
        rounded(g, x, y, w, h, r, 0xFF21262D);
        int fw = (int) Math.round(w * Math.max(0, Math.min(1, frac)));
        if (fw > 0) rounded(g, x, y, fw, h, Math.min(r, fw / 2), color);
    }

    public static int mix(int a, int b, float t) {
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, aa = a >>> 24;
        int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255, ba = b >>> 24;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16)
                | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static String money(long v) {
        return "$" + NumberFormat.getIntegerInstance(Locale.GERMANY).format(v);
    }

    public static String time(long ms) {
        long s = (ms + 999) / 1000;
        return String.format("%02d:%02d", s / 60, s % 60);
    }

    public static String trim(String s, int maxPx) {
        if (width(s) <= maxPx) return s;
        while (s.length() > 1 && width(s + "...") > maxPx) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    /** Einfacher animierter Button (kein Vanilla-Look). */
    public static final class Btn {
        public final int x, y, w, h;
        public final String label;
        public final int color;
        public final boolean enabled;
        public final Runnable action;

        public Btn(int x, int y, int w, int h, String label, int color, boolean enabled, Runnable action) {
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.label = label; this.color = color; this.enabled = enabled; this.action = action;
        }

        public boolean hit(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }

        public void draw(GuiGraphicsExtractor g, int mx, int my) {
            boolean hover = enabled && hit(mx, my);
            int base = enabled ? color : 0xFF30363D;
            int fill = mix(0xFF161B22, base, hover ? 0.55f : 0.28f);
            panel(g, x, y, w, h, fill, hover ? mix(base, 0xFFFFFFFF, 0.3f) : base);
            int tc = enabled ? TEXT : MUTED;
            centered(g, label, x + w / 2, y + (h - 8) / 2, tc);
        }
    }
}
