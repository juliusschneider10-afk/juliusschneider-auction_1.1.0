package de.juliusschneider.auction.ui;

import de.juliusschneider.auction.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.network.chat.Component;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import static de.juliusschneider.auction.ui.JuliusschneiderUi.*;

/** Haupt-GUI: IDLE, SETUP, RUNNING, ENDED + Bestaetigungsdialog. */
public class JuliusschneiderAuctionScreen extends JuliusschneiderBaseScreen {
    private final JuliusschneiderAuctionManager m = JuliusschneiderAuctionManager.get();
    private JuliusschneiderAuctionState shown;
    private Runnable confirmAction;
    private String confirmText = "";
    private EditBox minBidBox;
    private static final SimpleDateFormat TIME = new SimpleDateFormat("HH:mm:ss");

    public JuliusschneiderAuctionScreen() { super("JuliusSchneider Auction"); }

    @Override
    public void tick() {
        if (m.state() == JuliusschneiderAuctionState.SETUP && confirmAction == null) m.autoSelectFromHand();
        if (m.state() != shown) rebuildWidgets();
    }

    private void refresh() { rebuildWidgets(); }

    private void run(String err) {
        if (err != null) flash(err, true);
        refresh();
    }

    private void confirm(String text, Runnable action) {
        confirmText = text;
        confirmAction = action;
        refresh();
    }

    @Override
    protected void build() {
        shown = m.state();
        minBidBox = null;
        if (confirmAction != null) {
            int cx = px + pw / 2;
            btn(cx - 110, py + ph / 2 + 10, 100, 24, "JA", RED, () -> {
                Runnable a = confirmAction; confirmAction = null; a.run(); refresh();
            });
            btn(cx + 10, py + ph / 2 + 10, 100, 24, "NEIN", GREEN, () -> { confirmAction = null; refresh(); });
            return;
        }
        int bx = px + 14, by1 = py + ph - 58, by2 = py + ph - 32, w = pw - 28;
        switch (shown) {
            case IDLE -> {
                btn(px + pw / 2 - 110, py + 110, 220, 32, "NEUE AUKTION", GREEN, () -> run(m.enterSetup()));
                int bw = (w - 6) / 2;
                btn(bx, by2, bw, 22, "WERBUNG", GOLD, this::advert);
                btn(bx + bw + 6, by2, w - bw - 6, 22, "EINSTELLUNGEN", MUTED, this::openSettings);
            }
            case SETUP -> buildSetup();
            case RUNNING -> {
                int bw = (w - 6) / 2;
                btn(bx, by1, bw, 22, "TEST-MENUE", BLUE, () -> Minecraft.getInstance().setScreen(new JuliusschneiderTestScreen(this)));
                btn(bx + bw + 6, by1, w - bw - 6, 22, "WERBUNG", GOLD, this::advert);
                int bw3 = (w - 12) / 3;
                btn(bx, by2, bw3, 22, "BEENDEN", RED, () -> confirm("Auktion jetzt beenden?", () -> run(m.end())));
                btn(bx + bw3 + 6, by2, bw3, 22, "ABBRECHEN", RED, () -> confirm("Abbrechen? Alle Gebote muessen erstattet werden.", () -> run(m.abort())));
                btn(bx + 2 * (bw3 + 6), by2, w - 2 * (bw3 + 6), 22, "EINSTELLUNGEN", MUTED, this::openSettings);
            }
            case ENDED -> {
                btn(bx, by1, w, 22, "RUECKZAHLUNGEN (" + m.pendingRefunds().size() + ")", GOLD,
                        () -> Minecraft.getInstance().setScreen(new JuliusschneiderRefundScreen(this)));
                int bw3 = (w - 12) / 3;
                btn(bx, by2, bw3, 22, "ZURUECKSETZEN", RED, () -> confirm(
                        m.pendingRefunds().isEmpty() ? "Auktion zuruecksetzen?" : "Rueckzahlungen offen! Trotzdem zuruecksetzen?",
                        () -> run(m.reset())));
                btn(bx + bw3 + 6, by2, bw3, 22, "WERBUNG", GOLD, this::advert);
                btn(bx + 2 * (bw3 + 6), by2, w - 2 * (bw3 + 6), 22, "EINSTELLUNGEN", MUTED, this::openSettings);
            }
        }
    }

    private void advert() {
        String err = m.sendAdvert();
        if (err != null) flash(err, true); else flash("Werbung gesendet", false);
    }

    private void openSettings() { Minecraft.getInstance().setScreen(new JuliusschneiderSettingsScreen(this)); }

    // ---------- SETUP ----------
    private void buildSetup() {
        m.autoSelectFromHand();
        int rx = px + 212, rw = pw - 226;
        minBidBox = new EditBox(font, rx + 8, py + 44 + 24, rw - 16, 18, Component.literal("Mindestgebot"));
        minBidBox.setMaxLength(20);
        minBidBox.setFilter(s -> s.matches("[0-9.,kKmMbB$ ]*"));
        minBidBox.setValue(String.valueOf(m.minBid()));
        minBidBox.setResponder(s -> JuliusschneiderAmountParser.parse(s).ifPresent(v -> { if (v >= 1) m.setMinBid(v); }));
        addRenderableWidget(minBidBox);

        int cw = (rw - 16 - 3 * 4) / 4;
        for (int i = 0; i < JuliusschneiderAuctionManager.DURATIONS.length; i++) {
            int sec = JuliusschneiderAuctionManager.DURATIONS[i];
            int row = i / 4, col = i % 4;
            boolean sel = sec == m.durationSeconds();
            btn(rx + 8 + col * (cw + 4), py + 104 + 22 + row * 26, cw, 20,
                    JuliusschneiderAuctionManager.DURATION_LABELS[i], sel ? GOLD : MUTED, () -> {
                        String e = m.setDuration(sec); if (e != null) flash(e, true); refresh(); });
        }
        int by = py + ph - 46, w = pw - 28;
        int sw = (int) (w * 0.6) - 4;
        btn(px + 14, by, sw, 28, "AUKTION STARTEN", GREEN, () -> {
            var parsed = JuliusschneiderAmountParser.parse(minBidBox == null ? "" : minBidBox.getValue());
            if (parsed.isEmpty() || parsed.getAsLong() < 1) { flash("Ungueltiges Mindestgebot", true); return; }
            String e = m.setMinBid(parsed.getAsLong());
            if (e == null) e = m.start();
            run(e);
        });
        btn(px + 14 + sw + 8, by, w - sw - 8, 28, "ABBRECHEN", RED, () -> run(m.cancelSetup()));
    }

    @Override
    protected void backdropExtras(GuiGraphicsExtractor g) {
        if (confirmAction != null || m.state() != JuliusschneiderAuctionState.SETUP) return;
        panel(g, px + 14, py + 44, 186, 112, PANEL, BORDER);
        panel(g, px + 212, py + 44, pw - 226, 52, PANEL, BORDER);
        panel(g, px + 212, py + 104, pw - 226, 74, PANEL, BORDER);
    }

    // ---------- Zeichnen ----------
    @Override
    protected void draw(GuiGraphicsExtractor g, int mx, int my) {
        textScaled(g, "JULIUSSCHNEIDER AUCTION", px + 14, py + 12, GOLD, 1.3f);
        String badge = switch (m.state()) {
            case IDLE -> "BEREIT"; case SETUP -> "SETUP"; case RUNNING -> "LIVE"; case ENDED -> "BEENDET";
        };
        int bc = switch (m.state()) { case RUNNING -> GREEN; case ENDED -> RED; case SETUP -> BLUE; default -> MUTED; };
        panel(g, px + pw - 14 - width(badge) - 14, py + 10, width(badge) + 14, 16, mix(BG, bc, 0.25f), bc);
        text(g, badge, px + pw - 14 - width(badge) - 7, py + 14, bc);

        if (confirmAction != null) {
            panel(g, px + pw / 2 - 150, py + ph / 2 - 40, 300, 90, PANEL_HI, RED);
            centered(g, "BESTAETIGUNG", px + pw / 2, py + ph / 2 - 30, RED);
            centered(g, trim(confirmText, 280), px + pw / 2, py + ph / 2 - 10, TEXT);
            return;
        }
        switch (m.state()) {
            case IDLE -> {
                centered(g, "Keine Auktion aktiv", px + pw / 2, py + 70, TEXT);
                centered(g, "Starte eine neue Auktion mit dem Item aus deiner Hand.", px + pw / 2, py + 84, MUTED);
            }
            case SETUP -> drawSetup(g);
            case RUNNING, ENDED -> drawAuction(g);
        }
    }

    private void drawSetup(GuiGraphicsExtractor g) {
        int ix = px + 14, iy = py + 44;
        text(g, "ITEM", ix + 8, iy + 6, MUTED);
        if (m.hasItem()) {
            item(g, m.item(), ix + 12, iy + 26, 3f);
            text(g, trim(m.itemName(), 100), ix + 70, iy + 36, TEXT);
            text(g, "Anzahl: " + m.item().getCount(), ix + 70, iy + 50, MUTED);
        } else {
            text(g, "Kein Item gewaehlt", ix + 70, iy + 40, MUTED);
        }
        text(g, "Item in der Hand halten", ix + 8, iy + 94, MUTED);
        int rx = px + 212;
        text(g, "MINDESTGEBOT", rx + 8, py + 50, MUTED);
        text(g, "LAUFZEIT", rx + 8, py + 110, MUTED);
    }

    private void drawAuction(GuiGraphicsExtractor g) {
        boolean running = m.state() == JuliusschneiderAuctionState.RUNNING;
        long rem = m.remainingMs();
        boolean urgent = running && rem <= 10_000;
        var leader = running ? m.leader() : m.winner();
        int lx = px + 14, ly = py + 44, lw = 256, lh = 92;

        long since = System.currentTimeMillis() - m.leaderChangedAtMs();
        float anim = m.leaderChangedAtMs() > 0 && since < 900 ? 1f - since / 900f : 0f;
        int border = mix(BORDER, GOLD, Math.max(anim, leader != null ? 0.35f : 0f));
        panel(g, lx, ly, lw, lh, mix(PANEL, GOLD, anim * 0.25f), border);
        String head = running ? "FUEHREND" : (m.cancelled() ? "ABGEBROCHEN" : (leader == null ? "KEINE GEBOTE" : "GEWINNER"));
        text(g, head, lx + 10, ly + 8, running ? GOLD : (leader == null ? MUTED : GREEN));
        if (leader != null) {
            int slide = (int) (anim * anim * 24);
            JuliusschneiderSkinManager.get().drawHead(g, leader.player(), lx + 12 + slide, ly + 28, 40);
            textScaled(g, trim(leader.player(), 160), lx + 62 + slide, ly + 32, TEXT, 1.5f);
            textScaled(g, money(leader.amount()), lx + 62 + slide, ly + 56, running ? GOLD : GREEN, 1.5f);
        } else {
            text(g, running ? "Noch kein Gebot" : (m.cancelled() ? "Keine Vergabe" : "Niemand hat geboten"), lx + 12, ly + 44, MUTED);
            text(g, "Mindestgebot: " + money(m.minBid()), lx + 12, ly + 58, MUTED);
        }
        if (!running && leader != null)
            text(g, "Item: " + trim(m.itemName(), 170) + " x" + m.item().getCount(), lx + 12, ly + 78, GREEN);

        int rx = px + 278, rw = pw - 292;
        panel(g, rx, ly, rw, lh, PANEL, BORDER);
        item(g, m.item(), rx + 8, ly + 8, 2f);
        text(g, trim(m.itemName(), rw - 52), rx + 46, ly + 10, TEXT);
        text(g, "Min: " + money(m.minBid()), rx + 46, ly + 22, MUTED);
        text(g, "EINNAHMEN", rx + 8, ly + 50, MUTED);
        text(g, trim(money(m.totalRevenue()), rw - 16), rx + 8, ly + 64, GREEN);

        int col = urgent ? ((System.currentTimeMillis() / 300) % 2 == 0 ? RED : mix(RED, TEXT, 0.4f)) : (running ? TEXT : MUTED);
        textScaled(g, running ? time(rem) : "BEENDET", lx, py + 142, col, 2f);
        textRight(g, m.bidCount() + " Gebote", px + pw - 14, py + 148, MUTED);
        bar(g, lx, py + 164, pw - 28, 8, m.progress(), urgent ? RED : (running ? GOLD : MUTED));

        int by = py + 178, bw = pw - 28;
        panel(g, lx, by, bw, 70, PANEL, BORDER);
        text(g, "LETZTE GEBOTE", lx + 8, by + 5, MUTED);
        List<JuliusschneiderBid> recent = m.recentBids();
        for (int i = 0; i < Math.min(4, recent.size()); i++) {
            var b = recent.get(i);
            int ry = by + 17 + i * 13;
            JuliusschneiderSkinManager.get().drawHead(g, b.player(), lx + 8, ry, 10);
            text(g, trim(b.player(), 120), lx + 22, ry + 1, TEXT);
            text(g, TIME.format(new Date(b.timeMs())) + "  #" + b.id(), lx + 150, ry + 1, MUTED);
            textRight(g, money(b.amount()), lx + bw - 8, ry + 1, i == 0 ? GOLD : TEXT);
        }
        if (recent.isEmpty()) text(g, "Noch keine Gebote", lx + 8, by + 22, MUTED);
    }
}
